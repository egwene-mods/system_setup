# system_setup
setup scripts for systems like new windows machine, new VM, new linux box, whatever
